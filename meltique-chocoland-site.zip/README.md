# MeltiQue Chocoland website (GitHub Pages)

Files: index.html, privacy.html, terms.html, css/styles.css, js/config.js, js/main.js, assets/

## Before publishing
1. Open js/config.js and set `whatsappNumber` to the SAME number your current site uses (digits with country code, e.g. 91XXXXXXXXXX).
2. Check `instagramUrl` matches your current Instagram link exactly.
3. If you have a logo file, put it in assets/ and set `logoSrc: "assets/your-logo.png"`.

## Publish on GitHub Pages
1. Open your site's repository on github.com.
2. Add file > Upload files. Drag in everything from this folder (keep the css, js and assets folders). Same file names replace the old ones.
3. Commit changes. Pages rebuilds in about a minute.
4. Remove old files you no longer need (old policy pages, old images) with the trash icon on each file.
5. Hard refresh the live site (Ctrl+Shift+R) to see the update.
