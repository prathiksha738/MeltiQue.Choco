/* ==========================================================
   MeltiQue Chocoland: all editable content lives in this file.
   Change product names, descriptions and statuses here only.
   ========================================================== */
window.MQ = {
  brand: "MeltiQue Chocoland",
  tagline: "BEYOND CHOCOLATE…",

  /* WhatsApp number: digits only, with country code, e.g. "91XXXXXXXXXX".
     Paste the SAME number your current website uses. Until it is filled,
     buttons open WhatsApp with the message ready but no chat selected. */
  whatsappNumber: "",

  /* Keep the same Instagram link your current site uses. */
  instagramUrl: "https://www.instagram.com/meltiqu.choco",
  instagramHandle: "@meltiqu.choco",

  email: "MeltiQu.choco@gmail.com",
  address: "Parappalayam, Mangalam Road, Tirupur, Tamil Nadu 641604",

  /* Optional: path to your existing logo image, e.g. "assets/logo.png".
     Leave empty to show the text wordmark. */
  logoSrc: "",

  /* status: "now" | "pre" | "soon"
     action: "order" | "preorder" | "explore" | "launch"
     note:   small line shown on the card (use for "to be confirmed" items) */
  available: [
    { name: "Chocolate Bars", status: "now", action: "order",
      desc: "Classic chocolate bars, made for everyday cravings." },
    { name: "Coffee Chocolate", status: "now", action: "order",
      desc: "Rich chocolate with a coffee character, for slow, thoughtful bites." },
    { name: "Honey Chocolate", status: "now", action: "order",
      desc: "Smooth chocolate paired with the gentle sweetness of honey." },
    { name: "Nut Chocolate", status: "now", action: "order",
      desc: "Chocolate with a satisfying nutty bite." },
    { name: "Cookies with Chocolate Fillings", status: "now", action: "order",
      desc: "Cookies with a chocolate centre, ordered through WhatsApp." },
    { name: "Chocolate Bombs", status: "now", action: "order",
      desc: "A showpiece chocolate treat, available through WhatsApp." },
    { name: "Chocolate-covered Fruits and Nuts", status: "now", action: "order",
      desc: "Fruits and nuts wrapped in chocolate.",
      note: "Please confirm availability on WhatsApp before ordering." }
  ],

  preorder: [
    { name: "Brownie Bites", status: "pre", action: "preorder",
      desc: "Bite-sized chocolate brownies, reserved in advance." },
    { name: "Cocoa Truffles", status: "pre", action: "preorder",
      desc: "Soft, cocoa-rich truffles made to be shared or savoured alone." },
    { name: "Chocolate Dips", status: "pre", action: "preorder",
      desc: "Chocolate dips for fruit, snacks and gatherings." },
    { name: "Donut-shaped Chocolates", status: "pre", action: "preorder",
      desc: "Playful donut-shaped chocolates, made on request." },
    { name: "Personalized Chocolates", status: "pre", action: "preorder",
      desc: "Chocolates shaped around a name, a message or an occasion.",
      note: "Customization details are confirmed on WhatsApp." },
    { name: "Chocolate Fudge", status: "pre", action: "preorder",
      desc: "Dense, indulgent chocolate fudge.",
      note: "Subject to confirmation." }
  ],

  gifts: [
    { name: "Create Your Own Chocolate Box", status: "pre", action: "preorder",
      label: "Pre-order Available",
      desc: "Tell us your preferred combinations and we will talk through what can go in your box.",
      note: "Combinations are confirmed before your order is accepted." },
    { name: "Secret Message Chocolate", status: "concept", action: "preorder",
      label: "Concept in Development · Pre-order Enquiries Available",
      desc: "A chocolate gift that carries a personal message.",
      note: "Final design and availability must be confirmed." },
    { name: "Chocolate & Lifestyle Gift Bundles", status: "concept", action: "preorder",
      label: "Concept in Development · Pre-order Enquiries Available",
      desc: "A proposed pairing of chocolate with suitable gift items.",
      note: "Contents are not fixed. Nothing is promised until confirmed." },
    { name: "Limited-Edition Celebration Boxes", status: "pre", action: "preorder",
      label: "Pre-order Available",
      desc: "Seasonal and occasion boxes.",
      themes: ["Halloween", "Diwali", "Christmas", "Pongal", "Birthdays", "Anniversaries", "Other festivals, functions, parties and celebrations"],
      note: "Availability depends on the collection schedule and production capacity." },
    { name: "Say It with Chocolate", status: "pre", action: "preorder",
      label: "Pre-order Available",
      desc: "Personalized chocolate gifting for messages, celebrations and special occasions.",
      note: "Exact customization is confirmed on WhatsApp." }
  ],

  lab: [
    { name: "Puzzle Chocolates / Puzzle Packaging", status: "soon", action: "explore",
      desc: "A chocolate gift or packaging idea with a puzzle and discovery element. The final design is not set." },
    { name: "More Chocolate Collections", status: "soon", action: "launch",
      desc: "A preview of future flavours, shapes and limited editions. Nothing here is available yet." },
    { name: "Surprise Discovery Box", status: "soon", action: "explore",
      desc: "A possible gift box built around surprise and discovery. Contents are not yet decided." },
    { name: "Chocolate Marshmallows", status: "soon", action: "launch",
      desc: "Marshmallows with a chocolate twist, in development." },
    { name: "Dessert Cups", status: "soon", action: "launch",
      desc: "Chocolate dessert cups, in development." },
    { name: "Chocolate-covered Popcorn", status: "soon", action: "launch",
      desc: "Popcorn dipped in chocolate. Coming soon unless confirmed available." },
    { name: "Protein Chocolates", status: "soon", action: "launch",
      desc: "An idea still in development. No nutritional claims are made." },
    { name: "Piku Chocolate", status: "soon", action: "explore",
      desc: "A future collection under MeltiQue Chocoland. See Piku below." }
  ]
};
