(function () {
  'use strict';
  var C = window.MQ;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var small = window.matchMedia('(max-width: 800px)').matches;
  var fine = window.matchMedia('(pointer:fine)').matches;

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---------- WhatsApp ---------- */
  function wa(text) {
    var base = C.whatsappNumber ? 'https://wa.me/' + String(C.whatsappNumber).replace(/\D/g, '') : 'https://wa.me/';
    return base + '?text=' + encodeURIComponent(text);
  }
  function msg(item) {
    var b = C.brand;
    switch (item.action) {
      case 'order': return 'Hi ' + b + '! I would like to order: ' + item.name + '.';
      case 'preorder': return 'Hi ' + b + '! Pre-order enquiry: ' + item.name + '. Please confirm availability, price, customization and the estimated fulfilment date.';
      case 'launch': return 'Hi ' + b + '! Please add me to the launch list for: ' + item.name + '.';
      default: return 'Hi ' + b + '! I would like to know more about this idea: ' + item.name + '.';
    }
  }
  var BTN = { order: 'Order on WhatsApp', preorder: 'Pre-order Enquiry', explore: 'Explore Idea', launch: 'Join Launch List' };
  var STAT = { now: ['st-now', 'Available Now'], pre: ['st-pre', 'Pre-order Available'], concept: ['st-concept', 'Concept in Development'], soon: ['st-soon', 'Coming Soon'] };

  /* ---------- text-only product cards (no images, no motion) ---------- */
  function card(it) {
    var st = STAT[it.status] || STAT.soon;
    var label = it.label || st[1];
    var h = '<article class="item"><span class="status ' + st[0] + '">' + esc(label) + '</span>' +
      '<h4>' + esc(it.name) + '</h4><p>' + esc(it.desc) + '</p>';
    if (it.themes) h += '<ul class="themes" aria-label="Possible themes">' + it.themes.map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('') + '</ul>';
    if (it.note) h += '<p class="note">' + esc(it.note) + '</p>';
    h += '<div class="actions-row"><a class="btn btn-' + (it.action === 'order' || it.action === 'preorder' ? 'gold' : 'line') + ' btn-sm" href="' + wa(msg(it)) +
      '" target="_blank" rel="noopener" aria-label="' + esc(BTN[it.action] + ': ' + it.name) + '">' + BTN[it.action] + '</a></div></article>';
    return h;
  }
  function fill(id, list) { var el = document.getElementById(id); if (el) el.innerHTML = list.map(card).join(''); }
  fill('listAvailable', C.available);
  fill('listPre', C.preorder);
  fill('listGifts', C.gifts);
  fill('listLab', C.lab);

  /* ---------- static WhatsApp links ---------- */
  document.querySelectorAll('[data-wa]').forEach(function (a) { a.href = wa(a.getAttribute('data-wa')); });
  var bb = document.getElementById('bulkBtn');
  if (bb) bb.href = wa('Hi ' + C.brand + '! Bulk order enquiry.\nOccasion:\nApproximate quantity:\nPreferred products:\nCustomization:\nRequired date:');

  /* ---------- contact facts ---------- */
  document.getElementById('fAddr').textContent = C.address;
  document.getElementById('fMail').innerHTML = '<a href="mailto:' + esc(C.email) + '">' + esc(C.email) + '</a>';
  document.getElementById('fIg').innerHTML = '<a href="' + esc(C.instagramUrl) + '" target="_blank" rel="noopener">' + esc(C.instagramHandle) + '</a>';
  document.getElementById('yr').textContent = new Date().getFullYear();
  if (C.logoSrc) {
    var li = document.getElementById('logoImg'); li.src = C.logoSrc; li.hidden = false;
    document.getElementById('logoText').hidden = true;
  }

  /* ---------- nav ---------- */
  var nav = document.getElementById('nav'), links = document.getElementById('links'), mb = document.getElementById('menuBtn');
  function onScroll() { nav.classList.toggle('solid', window.scrollY > 40); }
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });
  function setMenu(open) { links.classList.toggle('open', open); mb.setAttribute('aria-expanded', open); mb.setAttribute('aria-label', open ? 'Close menu' : 'Open menu'); }
  mb.addEventListener('click', function () { setMenu(!links.classList.contains('open')); });
  links.addEventListener('click', function (e) { if (e.target.tagName === 'A') setMenu(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });

  /* current section highlight */
  if ('IntersectionObserver' in window) {
    var anchors = {};
    links.querySelectorAll('a').forEach(function (a) { anchors[a.getAttribute('href').slice(1)] = a; });
    var so = new IntersectionObserver(function (es) {
      es.forEach(function (e) { var a = anchors[e.target.id]; if (a) a.classList.toggle('on', e.isIntersecting); });
    }, { rootMargin: '-40% 0px -55% 0px' });
    Object.keys(anchors).forEach(function (id) { var s = document.getElementById(id); if (s) so.observe(s); });
  }

  /* ---------- decorative paws (background areas only) ---------- */
  function paws(host, n) {
    var html = '';
    for (var i = 0; i < n; i++) {
      var s = 30 + Math.random() * 60;
      html += '<span class="paw" style="left:' + (Math.random() * 94).toFixed(1) + '%;top:' + (Math.random() * 88).toFixed(1) +
        '%;--s:' + s.toFixed(0) + 'px;--r:' + ((Math.random() * 80) - 40).toFixed(0) + 'deg;--d:' + (11 + Math.random() * 9).toFixed(1) +
        's;animation-delay:-' + (Math.random() * 10).toFixed(1) + 's"><svg aria-hidden="true"><use href="#paw"/></svg></span>';
    }
    host.innerHTML = html;
  }
  var hp = document.getElementById('heroPaws'); if (hp) paws(hp, small ? 5 : 9);
  document.querySelectorAll('[data-paws]').forEach(function (h) { paws(h, parseInt(h.getAttribute('data-paws'), 10)); });

  /* ---------- word-explosion headings ---------- */
  var xps = [];
  document.querySelectorAll('[data-xp]').forEach(function (h) {
    var text = h.textContent;
    h.setAttribute('aria-label', text);
    h.textContent = '';
    var wrap = document.createElement('span'); wrap.className = 'xp'; wrap.setAttribute('aria-hidden', 'true');
    text.split(' ').forEach(function (w, wi, arr) {
      var ws = document.createElement('span'); ws.style.cssText = 'display:inline-block;white-space:nowrap';
      Array.from(w).forEach(function (c) { var s = document.createElement('span'); s.className = 'ch'; s.textContent = c; ws.appendChild(s); });
      wrap.appendChild(ws);
      if (wi < arr.length - 1) wrap.appendChild(document.createTextNode(' '));
    });
    h.appendChild(wrap);
    xps.push(wrap);
  });
  function assemble(wrap, delayBase) {
    if (reduce) return;
    wrap.querySelectorAll('.ch').forEach(function (c, i) {
      var a = Math.random() * 6.283, d = 60 + Math.random() * 120;
      c.animate([
        { opacity: 0, transform: 'translate(' + Math.cos(a) * d + 'px,' + Math.sin(a) * d + 'px) rotate(' + (Math.random() * 120 - 60) + 'deg) scale(.4)', filter: 'blur(6px)' },
        { opacity: 1, transform: 'none', filter: 'blur(0)' }
      ], { duration: 1300, delay: (delayBase || 0) + i * 22, easing: 'cubic-bezier(.2,.7,.2,1)', fill: 'backwards' });
    });
  }
  function explode(wrap) {
    if (reduce) return;
    wrap.querySelectorAll('.ch').forEach(function (c) {
      var a = Math.random() * 6.283, d = 40 + Math.random() * 90;
      c.animate([
        { transform: 'none', opacity: 1 },
        { transform: 'translate(' + Math.cos(a) * d + 'px,' + Math.sin(a) * d + 'px) rotate(' + (Math.random() * 90 - 45) + 'deg)', opacity: .2, offset: .4 },
        { transform: 'none', opacity: 1 }
      ], { duration: 1500, easing: 'cubic-bezier(.2,.7,.2,1)' });
    });
  }
  if (fine) xps.forEach(function (w) { w.parentNode.addEventListener('pointerenter', function () { explode(w); }); });

  /* ---------- scroll reveal: in on the way down, out on the way up ---------- */
  var rv = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !reduce) {
    var seen = new WeakSet();
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        e.target.classList.toggle('in', e.isIntersecting);
        if (e.isIntersecting) {
          e.target.querySelectorAll('.xp').forEach(function (x) { if (!seen.has(x)) { seen.add(x); assemble(x, 150); } });
        }
      });
    }, { threshold: 0.12 });
    rv.forEach(function (r) { io.observe(r); });
    /* headings that sit inside .head.reveal are handled above; keep others visible */
  } else {
    rv.forEach(function (r) { r.classList.add('in'); });
  }

  /* ---------- hero WebGL: floating chocolate pieces and gold dust ---------- */
  var hero = document.getElementById('hero'), canvas = document.getElementById('gl');
  function initGL() {
    try {
      if (!window.THREE) throw 0;
      var T = THREE;
      var r = new T.WebGLRenderer({ canvas: canvas, antialias: !small, alpha: true });
      r.setPixelRatio(Math.min(window.devicePixelRatio || 1, small ? 1.5 : 2));
      var scene = new T.Scene(), cam = new T.PerspectiveCamera(42, 1, .1, 50); cam.position.z = 7.5;
      scene.add(new T.AmbientLight(0x4a2a1c, 1.1));
      var k = new T.DirectionalLight(0xffe3b0, 1.7); k.position.set(-4, 5, 6); scene.add(k);
      var p1 = new T.PointLight(0xd9903f, 2.2, 22); p1.position.set(4, -1, 4); scene.add(p1);
      var p2 = new T.PointLight(0x9a2a40, 1.5, 20); p2.position.set(-5, -3, 2); scene.add(p2);
      function rr(s, w, h, rad) {
        var x = -w / 2, y = -h / 2;
        s.moveTo(x + rad, y); s.lineTo(x + w - rad, y); s.quadraticCurveTo(x + w, y, x + w, y + rad);
        s.lineTo(x + w, y + h - rad); s.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
        s.lineTo(x + rad, y + h); s.quadraticCurveTo(x, y + h, x, y + h - rad);
        s.lineTo(x, y + rad); s.quadraticCurveTo(x, y, x + rad, y); return s;
      }
      var gB = new T.ExtrudeGeometry(rr(new T.Shape(), 1, 1, .13), { depth: .22, bevelEnabled: true, bevelThickness: .06, bevelSize: .05, bevelSegments: 3, curveSegments: 5 });
      var gI = new T.ExtrudeGeometry(rr(new T.Shape(), .64, .64, .09), { depth: .05, bevelEnabled: true, bevelThickness: .02, bevelSize: .02, bevelSegments: 2, curveSegments: 4 });
      var mB = new T.MeshStandardMaterial({ color: 0x2a140c, roughness: .26, metalness: .2 });
      var mI = new T.MeshStandardMaterial({ color: 0x3b1d11, roughness: .2, metalness: .25 });
      var mG = new T.MeshStandardMaterial({ color: 0xd9b979, roughness: .3, metalness: .85 });
      var group = new T.Group(); scene.add(group); var pieces = [];
      var n = small ? 5 : 9;
      for (var i = 0; i < n; i++) {
        var g = new T.Group(), a = new T.Mesh(gB, mB), b = new T.Mesh(gI, i % 4 === 0 ? mG : mI); b.position.z = .3; g.add(a); g.add(b);
        g.scale.setScalar(.55 + Math.random() * .85);
        g.position.set(small ? Math.random() * 6 - 3 : 1 + Math.random() * 4.6, (Math.random() - .5) * 5, -2 + Math.random() * 3.2);
        g.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3);
        g.userData = { sx: (Math.random() - .5) * .006, sy: (Math.random() - .5) * .008, bob: Math.random() * 6, amp: .12 + Math.random() * .2, y0: g.position.y };
        group.add(g); pieces.push(g);
      }
      var c = document.createElement('canvas'); c.width = c.height = 64; var x = c.getContext('2d');
      var gr = x.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,236,190,1)'); gr.addColorStop(.35, 'rgba(232,200,130,.55)'); gr.addColorStop(1, 'rgba(217,185,121,0)');
      x.fillStyle = gr; x.fillRect(0, 0, 64, 64);
      var pc = small ? 100 : 240, pos = new Float32Array(pc * 3);
      for (var q = 0; q < pc; q++) { pos[q * 3] = (Math.random() - .5) * 16; pos[q * 3 + 1] = (Math.random() - .5) * 10; pos[q * 3 + 2] = (Math.random() - .5) * 8; }
      var pg = new T.BufferGeometry(); pg.setAttribute('position', new T.BufferAttribute(pos, 3));
      var dust = new T.Points(pg, new T.PointsMaterial({ size: .16, map: new T.CanvasTexture(c), transparent: true, depthWrite: false, blending: T.AdditiveBlending, opacity: .85 }));
      scene.add(dust);
      var tx = 0, ty = 0, mx = 0, my = 0, run = false, t0 = performance.now();
      function size() { var w = hero.clientWidth, h = hero.clientHeight; r.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); }
      size(); if (window.ResizeObserver) new ResizeObserver(size).observe(hero);
      if (fine) window.addEventListener('pointermove', function (e) { tx = e.clientX / innerWidth - .5; ty = e.clientY / innerHeight - .5; }, { passive: true });
      function frame(now) {
        if (!run) return; requestAnimationFrame(frame);
        var t = (now - t0) / 1000; mx += (tx - mx) * .04; my += (ty - my) * .04;
        var sc = Math.min(1, scrollY / Math.max(1, hero.clientHeight));
        group.rotation.y = mx * .5; group.rotation.x = my * .3; group.position.y = sc * 2.2;
        pieces.forEach(function (p) { p.rotation.x += p.userData.sx; p.rotation.y += p.userData.sy; p.position.y = p.userData.y0 + Math.sin(t * .6 + p.userData.bob) * p.userData.amp; });
        dust.rotation.y = t * .012; r.render(scene, cam);
      }
      r.render(scene, cam);
      if (!reduce) new IntersectionObserver(function (es) { run = es[0].isIntersecting; if (run) requestAnimationFrame(frame); }).observe(hero);
    } catch (e) { canvas.style.display = 'none'; }
  }
  if (window.THREE) initGL(); else window.addEventListener('load', initGL);
})();
